package com.amar.library.provider.interfaces;

/**
 * Created by Amar Jain on 17/03/17.
 */

public interface IScreenInfoProvider {
    int getScreenHeight();
    int getScreenWidth();
}
