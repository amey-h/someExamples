package com.kodmap.app.kmrecyclerviewstickyheader;

public class ItemType {
    public static final Integer Post = 1;
    public static final Integer Header = 2;
}
