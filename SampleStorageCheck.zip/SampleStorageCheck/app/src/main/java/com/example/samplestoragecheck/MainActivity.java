package com.example.samplestoragecheck;

import androidx.appcompat.app.AppCompatActivity;
import androidx.core.app.ActivityCompat;

import android.content.Intent;
import android.os.Bundle;
import android.os.Environment;
import android.util.Log;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;

public class MainActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        Printer printer = Printer.getInstance(MainActivity.this);
        printer.d("This is main activity. Checking printer.d()");
        printer.e("Checking printer.e()");
        printer.i("Checking printer.i()");
        printer.w("Checking printer.w()");


        //writeFileToInternalStorage1();
        //writeFileToInternalStorage2();
        //readDataFromInternalStorage();
        //writeDataToExternalStorage();
    }


    ////////////////// Trying storage /////////////////

    public void writeFileToInternalStorage1() {//NOSONAR
        boolean success = false;
        File[] filesArray = null;
        try {
            File externalCacheDir = this.getExternalCacheDir();
            if (externalCacheDir == null) {
                externalCacheDir = this.getFilesDir();
            }
            File transifexDir = new File(externalCacheDir.getAbsolutePath() + "/" + "terms" + "/");
            //If File is not present create directory
            if (!transifexDir.exists()) {
                transifexDir.mkdirs();
            }
            File outputFile = new File(transifexDir, "logs.txt");//Create Output file in Main File
            //Create New File if not present
            if (!outputFile.exists()) {
                outputFile.createNewFile();
            }
            FileWriter filewriter = new FileWriter(outputFile);
            BufferedWriter out = new BufferedWriter(filewriter);
            out.write("This is a sample logs txt file. Hello World!");
            out.close();

        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    public void writeFileToInternalStorage2() {
        boolean success = false;
        File[] filesArray = null;
        try {
            File externalCacheDir = this.getExternalCacheDir();
            if (externalCacheDir == null) {
                filesArray = this.getExternalFilesDirs(null);
                Log.d("Files[]", " : " + filesArray);
            }
            File transifexDir2 = new File(filesArray[0].getAbsolutePath() + "/" + "terms" + "/");
            //If File is not present create directory
            if (!transifexDir2.exists()) {
                transifexDir2.mkdirs();
            }
            File outputFile2 = new File(transifexDir2, "logs.txt");//Create Output file in Main File
            //Create New File if not present
            if (!outputFile2.exists()) {
                outputFile2.createNewFile();
            }
            FileWriter filewriter2 = new FileWriter(outputFile2);
            BufferedWriter out2 = new BufferedWriter(filewriter2);
            out2.write("This is a sample logs txt file. Hello World!");
            out2.close();
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    public void readDataFromInternalStorage() {
        StringBuilder text = new StringBuilder();
        BufferedReader br = null;
        try {
            File externalCacheDir = this.getExternalCacheDir();
            if (externalCacheDir == null) {
                externalCacheDir = this.getFilesDir();
            }
            File transifexDir = new File(externalCacheDir.getAbsolutePath() + "/" + "terms" + "/");
            File file = new File(transifexDir, "logs.txt");

            br = new BufferedReader(new FileReader(file));
            String line;
            while ((line = br.readLine()) != null) {
                text.append(line);
                Log.i("Test", "text : " + text + " : end");
                text.append('\n');
            }
        } catch (IOException e) {
            e.printStackTrace();

        } finally {
            try {
                br.close();
            } catch (IOException e) {
                e.printStackTrace();
            }
        }
        TextView tv = (TextView) findViewById(R.id.text);
        tv.setText(text.toString()); ////Set the text to text view.
    }

    EditText uname, pwd;
    Button saveBtn;
    FileOutputStream fstream;
    Intent intent;
    String username = "admin";
    String password = "Test@123";

    public void writeDataToExternalStorage() {
        if (isExternalStorageAvailable()) {
            try {
                ActivityCompat.requestPermissions(MainActivity.this, new String[]{android.Manifest.permission.READ_EXTERNAL_STORAGE}, 23);
                File folder = Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_DOWNLOADS);
                File myFile = new File(folder, "user_details.txt");
                if (!myFile.exists()) {
                    //myFile.mkdir();
                    fstream = new FileOutputStream(myFile);
                    fstream.write(username.getBytes());
                    fstream.write(password.getBytes());
                    fstream.close();
                }
                Toast.makeText(getApplicationContext(), "Details Saved in " + myFile.getAbsolutePath(), Toast.LENGTH_SHORT).show();
                //intent = new Intent(MainActivity.this,DetailsActivity.class);
                //startActivity(intent);
            } catch (FileNotFoundException e) {
                e.printStackTrace();
            } catch (IOException e) {
                e.printStackTrace();
            }
        }
    }

    private static boolean isExternalStorageReadOnly() {
        String extStorageState = Environment.getExternalStorageState();
        if (Environment.MEDIA_MOUNTED_READ_ONLY.equals(extStorageState)) {
            return true;
        }
        return false;
    }

    private static boolean isExternalStorageAvailable() {
        String extStorageState = Environment.getExternalStorageState();
        if (Environment.MEDIA_MOUNTED.equals(extStorageState)) {
            return true;
        }
        return false;
    }
}
