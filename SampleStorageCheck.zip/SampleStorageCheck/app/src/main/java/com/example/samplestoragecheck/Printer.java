package com.example.samplestoragecheck;

import android.content.Context;
import android.content.Intent;
import android.net.Uri;
import android.text.TextUtils;
import android.util.Log;

import androidx.annotation.NonNull;

import java.io.BufferedWriter;
import java.io.File;
import java.io.FileWriter;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.Locale;

public class Printer implements Thread.UncaughtExceptionHandler {

    private static final String TAG = Printer.class.getSimpleName();
    private Context context;
    private static final int LINE_MAX_CHARS = 2000; // basically used for DDMS
    private static final long MAX_FILE_SIZE = 10485760; // 10 MB
    private String filepath;
    private static Printer mInstance;

    public static Printer getInstance(Context c) {
        Log.d(TAG, "printer getInstance");
        if (mInstance == null) {
            mInstance = new Printer(c);
        }
        return mInstance;
    }

    public Printer(Context context) {

        Log.d(TAG, "printer constructor");
        this.context = context;
        File externalCacheDir = context.getExternalCacheDir();
        if (externalCacheDir == null) {
            Log.w(TAG, "externalCacheDir is null from getExternalCacheDir()");
            File[] fileArray = context.getExternalFilesDirs(null);
            if (fileArray != null) {
                if (fileArray[0] != null) {
                    externalCacheDir = new File(fileArray[0].getAbsolutePath());
                    if (externalCacheDir == null) {
                        Log.w(TAG, "externalCacheDir is null from getExternalFilesDirs()");
                        externalCacheDir = context.getFilesDir();
                        Log.d(TAG, "111 dir : " + externalCacheDir);
                    } else {
                        Log.d(TAG, "222 dir : " + externalCacheDir);
                    }

                }
            }
        }
        if (externalCacheDir != null) {
            StringBuilder filename = new StringBuilder(externalCacheDir.getAbsolutePath());
            filepath = filename.append("/logs.txt").toString();

            // set crash handler to log app crashes
            Thread.setDefaultUncaughtExceptionHandler(this);
            // set the file path and create a new log file if the current one is too big
            if (TextUtils.isEmpty(filepath)) {
                Log.w(TAG, "Cannot set file path. Path not found!");
            } else {
                final File file = new File(filepath);
                long len = file.length();
                Log.i(TAG, "length : " + len);
                if (file.length() > MAX_FILE_SIZE) {
                    BufferedWriter bufferWriter = null;
                    try {//NOSONAR
                        bufferWriter = new BufferedWriter(new FileWriter(filepath, false)); //NOSONAR
                        bufferWriter.write("Exceeded file size\n");
                    } catch (Exception e) {//NOSONAR
                        // do nothing
                        Log.e(TAG, e.getMessage());
                    } finally {
                        try {
                            if (bufferWriter != null) {//NOSONAR
                                bufferWriter.close();
                            }
                        } catch (Exception e) { //NOSONAR
                            Log.e(TAG, e.getMessage());
                        }
                    }
                }
                // updates the Media cache to let the file visible when connecting via usb
                context.sendBroadcast(new Intent(Intent.ACTION_MEDIA_SCANNER_SCAN_FILE, Uri.fromFile(file)));
            }
        } else {
            Log.w(TAG, "externalCacheDir is null from all methods.");
            return;
        }

    }

    /**
     * Log an INFO message concatenating the objects.
     * It uses StringBuffer to generate the String.
     *
     * @param objs Primitive and common types while for generic object it uses toString(). Also support Throwable which are stringified.
     **/
    public void i(final Object... objs) {
        msg(Log.INFO, objs);
    }

    /**
     * Log a WARN message concatenating the objects.
     * It uses StringBuffer to generate the String.
     *
     * @param objs Primitive and common types while for generic object it uses toString(). Also support Throwable which are stringified.
     **/
    public void w(final Object... objs) {
        msg(Log.WARN, objs);
    }

    /**
     * Log an ERROR message concatenating the objects.
     * It uses StringBuffer to generate the String.
     *
     * @param objs Primitive and common types while for generic object it uses toString(). Also support Throwable which are stringified.
     **/
    public void e(final Object... objs) {
        msg(Log.ERROR, objs);
    }

    /**
     * Log a DEBUG message concatenating the objects.
     * It uses StringBuffer to generate the String.
     *
     * @param objs Primitive and common types while for generic object it uses toString(). Also support Throwable which are stringified.
     **/
    public void d(final Object... objs) {
        msg(Log.DEBUG, objs);
    }


    protected synchronized void msg(final int type, final Object... objs) {
        StringBuilder message = new StringBuilder(objs.length);
        for (Object obj : objs) {
            if (obj instanceof Throwable) {
                message.append(Log.getStackTraceString((Throwable) obj));
            } else {
                message.append(obj);
            }
        }
        String tag = getRichTag();
        //if (!TextUtils.isEmpty(appPref.getEnv()) && !(appPref.getEnv().equalsIgnoreCase(Const.ENV_PROD))) {
        writeDdms(type, tag, message.toString());
        writeFile(type, tag, message.toString());
        //}
    }

    private void writeDdms(int type, String tag, String message) {
        for (final String line : splitLongMessage(message)) {
            Log.println(type, tag, line);
        }
    }

    private void writeFile(int type, String tag, String message) {
        if (!TextUtils.isEmpty(filepath)) {
            String messageTypePrefix = "";
            switch (type) {
                case Log.INFO:
                    messageTypePrefix = "I";
                    break;
                case Log.WARN:
                    messageTypePrefix = "W";
                    break;
                case Log.ERROR:
                    messageTypePrefix = "E";
                    break;
                case Log.DEBUG:
                    messageTypePrefix = "D";
                    break;
                default:
                    break;
            }
            BufferedWriter bufferWriter = null;
            try {//NOSONAR
                bufferWriter = new BufferedWriter(new FileWriter(filepath, true)); //NOSONAR
                String currentHumanTime = new SimpleDateFormat("MM-dd HH:mm:ss.SSS", Locale.US).format(new Date());
                bufferWriter.write(String.format("%s %s/%s:%s %n", currentHumanTime, messageTypePrefix, tag, message));
            } catch (Exception e) {//NOSONAR
                // do nothing
            } finally {
                try {
                    if (bufferWriter != null) {
                        bufferWriter.close();
                    }
                } catch (Exception e) { /* do nothing */ }//NOSONAR
            }
        }
    }

    private ArrayList<String> splitLongMessage(String message) {
        final ArrayList<String> messages = new ArrayList<>();
        int msgPartsCount = message.length() / LINE_MAX_CHARS;
        for (int i = 0; i < msgPartsCount; i++) {
            messages.add(message.substring(i * LINE_MAX_CHARS, (i + 1) * LINE_MAX_CHARS));
        }
        if (message.length() % LINE_MAX_CHARS != 0) {
            messages.add(message.substring(msgPartsCount * LINE_MAX_CHARS));
        }
        return messages;
    }

    /**
     * Generate a rich tag, containing the class and method names, the file and the line number.
     *
     * @return rich tag
     */
    private String getRichTag() {//NOSONAR
        String richTag = "VodafoneID : ";
        TagVerbosityLevel tagVerbosityLevel = TagVerbosityLevel.METHOD_NAME;
        if (tagVerbosityLevel != TagVerbosityLevel.NONE) {
            richTag += " ";
            boolean printerClassFoundPrev = false;
            try {
                final StackTraceElement[] stackTraceElements = Thread.currentThread().getStackTrace();
                for (StackTraceElement stackTraceElement : stackTraceElements) {
                    boolean printerClassFound = stackTraceElement.getClassName().equals(Printer.class.getName());
                    if (printerClassFoundPrev && !printerClassFound) {//NOSONAR
                        String className;
                        try {//NOSONAR
                            className = stackTraceElement.getClassName().substring(stackTraceElement.getClassName().lastIndexOf(".") + 1);//NOSONAR
                        } catch (Exception e) {//NOSONAR
                            className = stackTraceElement.getClassName();
                        }
                        switch (tagVerbosityLevel) {
                            case CLASS_NAME:
                                richTag += className;
                                break;
                            case METHOD_NAME:
                                richTag += String.format("%s/%s",
                                        className,
                                        stackTraceElement.getMethodName());
                                break;
                            case SOURCE_FILE:
                                richTag += String.format("%s/%s(%s)",
                                        className,
                                        stackTraceElement.getMethodName(),
                                        stackTraceElement.getFileName());
                                break;
                            case SOURCE_LINE://NOSONAR
                                richTag += String.format("%s/%s(%s:%s)",
                                        className,
                                        stackTraceElement.getMethodName(),
                                        stackTraceElement.getFileName(),
                                        stackTraceElement.getLineNumber());
                                break;
                            default:
                                break;
                        }
                        break;
                    }
                    printerClassFoundPrev = printerClassFound;
                }
            } catch (Exception e) {//NOSONAR
                // sets a default tag later
            }
        }
        return richTag;
    }

    public enum TagVerbosityLevel {
        /**
         * Use 'Printer'
         */
        NONE,
        /**
         * Use only the class name
         */
        CLASS_NAME,
        /**
         * Use class and method names
         */
        METHOD_NAME,
        /**
         * Use class, method and source file names
         */
        SOURCE_FILE,
        /**
         * Use class, method, source file names and source line number
         */
        SOURCE_LINE
    }

    @Override
    public void uncaughtException(@NonNull Thread thread, @NonNull Throwable throwable) {
        Log.e(TAG, "FATAL EXCEPTION\n", throwable);
    }
}
