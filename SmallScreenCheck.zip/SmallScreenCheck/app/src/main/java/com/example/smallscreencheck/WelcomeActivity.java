package com.example.smallscreencheck;

import android.content.Intent;
import android.content.res.Configuration;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.QuickContactBadge;

import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;

public class WelcomeActivity extends AppCompatActivity {

    private static final String TAG = WelcomeActivity.class.getSimpleName();

    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        Configuration config = getResources().getConfiguration();
        int smallestDp = config.smallestScreenWidthDp;
        Log.d(TAG, "smallestWidhtDp: " + smallestDp);
        if (smallestDp <= 360) {
            // for smaller screen devices: here considered screen size of ~4.5
            setContentView(R.layout.activity_welcome_tnc_small);
        } else {
            // for normal/regular screens
            setContentView(R.layout.activity_welcome_tnc);
        }

        Button button = findViewById(R.id.tnc_accept_button);
        button.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                startActivity(new Intent(WelcomeActivity.this, DashboardActivity.class));
            }
        });

    }
}
