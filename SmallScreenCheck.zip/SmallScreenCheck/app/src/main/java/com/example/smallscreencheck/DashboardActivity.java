package com.example.smallscreencheck;

import android.content.Intent;
import android.content.res.Configuration;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;

import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;

public class DashboardActivity extends AppCompatActivity {

    private static final String TAG = DashboardActivity.class.getSimpleName();

    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        Configuration config = getResources().getConfiguration();
        int smallestDp = config.smallestScreenWidthDp;
        Log.d(TAG, "smallestWidhtDp: " + smallestDp);

        if (smallestDp <= 360) {
            // for smaller screen devices: here considered screen size of ~4.5
            setContentView(R.layout.activity_dashboard_guest_scroll_small);
        } else {
            // for normal/regular screens
            setContentView(R.layout.activity_dashboard_guest_scroll);
        }

        Button button = findViewById(R.id.dashboard_guest_loginButton);
        button.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                startActivity(new Intent(DashboardActivity.this, PNTutorialActivity.class));
            }
        });
    }
}
