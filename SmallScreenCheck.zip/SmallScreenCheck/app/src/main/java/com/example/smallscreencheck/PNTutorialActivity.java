package com.example.smallscreencheck;

import android.content.res.Configuration;
import android.os.Bundle;
import android.util.Log;

import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;

public class PNTutorialActivity extends AppCompatActivity {

    private static final String TAG = PNTutorialActivity.class.getSimpleName();

    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        Configuration config = getResources().getConfiguration();
        int smallestDp = config.smallestScreenWidthDp;
        Log.d(TAG, "smallestWidhtDp: " + smallestDp);
        if (smallestDp <= 360) {
            // for smaller screen devices: here considered screen size of ~4.5
            setContentView(R.layout.activity_tutorial_pn_small);
        } else {
            // for normal/regular screens
            setContentView(R.layout.activity_tutorial_pn);
        }
    }
}
