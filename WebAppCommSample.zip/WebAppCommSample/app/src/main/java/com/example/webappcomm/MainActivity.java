package com.example.webappcomm;

import android.annotation.SuppressLint;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.webkit.JavascriptInterface;
import android.webkit.WebView;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

public class MainActivity extends AppCompatActivity {

    private static final String TAG = MainActivity.class.getSimpleName();
    private WebView webView;
    private String baseUrlFilePath = "https://amey-h.github.io/webappcommunication/sampleweb.html"; //"file:///android_asset/sampleweb.html";
    private Button sendButton;
    private EditText editText;

    @SuppressLint("SetJavaScriptEnabled")
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        webView = findViewById(R.id.app_webview);
        editText = findViewById(R.id.editText);
        sendButton = findViewById(R.id.sendButton);

        webView.getSettings().setJavaScriptEnabled(true);
        webView.addJavascriptInterface(new WebAppInterface(), "WebAppInterface");
        WebView.setWebContentsDebuggingEnabled(true);
        webView.setWebViewClient(new MyWebviewClient());
        webView.loadUrl(baseUrlFilePath);

        sendButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                sendDataToWebView();
            }
        });
    }

    /**
     * Send data to webview through function updateFromNative.
     */
    private void sendDataToWebView() {
        Log.d(TAG, "sendDataToWebView : " + editText.getText());
        webView.evaluateJavascript(
                "javascript: " + "updateFromNative(\"" + editText.getText().toString() + "\")",
                null);
    }

    /**
     * WebAppInterface to receive callback.
     */
    public class WebAppInterface {

        /**
         * Receive message from webview and pass on to app.
         */
        @JavascriptInterface
        public void showMessageInApp(final String message) {
            Log.d(TAG, "showToast:" + message);
            Toast.makeText(MainActivity.this, message, Toast.LENGTH_SHORT).show();
            editText.setText(message);
        }
    }
}