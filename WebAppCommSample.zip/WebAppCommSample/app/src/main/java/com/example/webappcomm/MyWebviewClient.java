package com.example.webappcomm;

import android.net.Uri;
import android.os.Build;
import android.util.Log;
import android.webkit.WebResourceRequest;
import android.webkit.WebView;
import android.webkit.WebViewClient;

import androidx.annotation.RequiresApi;

class MyWebviewClient extends WebViewClient {

    private static final String TAG = MyWebviewClient.class.getSimpleName();

    public MyWebviewClient() {
        Log.d(TAG, "Constructor:");
    }

    @Override
    public boolean shouldOverrideUrlLoading(WebView view, String url) {

        Log.d(TAG, "Host: " + Uri.parse(url).getHost());
        if ("https://amey-h.github.io/webappcommunication/".equals(Uri.parse(url).getHost())) {
            // This is my website, so do not override; let my WebView load the page
            return false;
        }
        // Otherwise, the link is not for a page on my site, so launch another Activity that handles URLs
        return true;
    }

    @RequiresApi(api = Build.VERSION_CODES.N)
    @Override
    public boolean shouldOverrideUrlLoading(WebView view, WebResourceRequest request) {

        Log.d(TAG, "Loading Url: " + request.getUrl());
        Log.d(TAG, "Host: " + Uri.parse(request.getUrl().toString()).getHost());

        if ("https://amey-h.github.io/webappcommunication/".equals(Uri.parse(request.getUrl().toString()).getHost())) {
            // This is my website, so do not override; let my WebView load the page
            return false;
        }
        // Otherwise, the link is not for a page on my site, so launch another Activity that handles URLs
        return true;
    }
}
