1. Fork the codebase and get codebase from `dev` branch
2. Make your changes and create a branch named `dev` followed by your name and feature (i.e) dev-bala-cache
3. Push your code to the branch, Make sure your code doesn't have any merge conflict with dev branch
4. Create a pull request. 

Hopefully within a day or two your pull request will be accepted and merged in codebase
