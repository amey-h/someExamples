package in.balakrishnan.easycam.capture;

/**
 * Created by BalaKrishnan
 */
public enum CameraSelection {
    FRONT, BACK
}
